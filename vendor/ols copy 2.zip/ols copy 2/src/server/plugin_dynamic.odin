package server

import "core:fmt"
import "core:log"
import "core:mem"
import "core:odin/ast"
import "core:os"
import "core:path/filepath"
import "src:common"
import "core:dynlib"

// Dynamic Plugin Loading using Odin FFI
// Based on examples from:
// - https://glennyonemitsu.com/post/live-reloading-dynamic-libraries-in-odin.html
// - https://github.com/karl-zylinski/odin-raylib-hot-reload-game-template

// Dynamic Plugin Library - common structure
DynamicPlugin :: struct {
    handle: dynlib.Library,
    path: string,
    loaded: bool,
}

// Platform-specific implementations using Odin's built-in dynamic library support

// Unix-like systems (Linux, macOS, etc.)
when ODIN_OS == .Linux || ODIN_OS == .Darwin {
    
    platform_load_plugin :: proc(path: string) -> DynamicPlugin {
        plugin := DynamicPlugin{path = path}
        
        // Use Odin's built-in dynamic library loading
        plugin.handle, plugin.loaded = dynlib.load_library(path)
        if !plugin.loaded {
            log.errorf("Failed to load plugin: %s", path)
            return plugin
        }
        
        log.infof("Successfully loaded plugin: %s", path)
        return plugin
    }
    
    platform_unload_plugin :: proc(plugin: DynamicPlugin) {
        if plugin.handle != nil {
            dynlib.unload_library(plugin.handle)
            log.infof("Successfully unloaded plugin: %s", plugin.path)
        }
    }
    
    platform_get_function :: proc(plugin: DynamicPlugin, symbol: string) -> rawptr {
        if plugin.handle == nil {
            return nil
        }
        
        func_ptr, found := dynlib.symbol_address(plugin.handle, symbol)
        
        if !found {
            log.errorf("Failed to get function %s from plugin %s", symbol, plugin.path)
            return nil
        }
        
        return func_ptr
    }
}

// Windows implementation
when ODIN_OS == .Windows {
    
    platform_load_plugin :: proc(path: string) -> DynamicPlugin {
        plugin := DynamicPlugin{path = path}
        
        plugin.handle, plugin.loaded = dynlib.load_library(path)
        if !plugin.loaded {
            log.errorf("Failed to load plugin: %s", path)
            return plugin
        }
        
        log.infof("Successfully loaded plugin: %s", path)
        return plugin
    }
    
    platform_unload_plugin :: proc(plugin: DynamicPlugin) {
        if plugin.handle != nil {
            dynlib.unload_library(plugin.handle)
            log.infof("Successfully unloaded plugin: %s", plugin.path)
        }
    }
    
    platform_get_function :: proc(plugin: DynamicPlugin, symbol: string) -> rawptr {
        if plugin.handle == nil {
            return nil
        }
        
        func_ptr, found := dynlib.symbol_address(plugin.handle, symbol)
        
        if !found {
            log.errorf("Failed to get function %s from plugin %s", symbol, plugin.path)
            return nil
        }
        
        return func_ptr
    }
}

// Fallback for other platforms - these will only be defined if no platform-specific version exists
when ODIN_OS != .Linux && ODIN_OS != .Darwin && ODIN_OS != .Windows {
    // Stub implementations for unsupported platforms
    platform_load_plugin :: proc(path: string) -> DynamicPlugin {
        log.errorf("Dynamic plugin loading not supported on platform: %s", ODIN_OS)
        return DynamicPlugin{loaded = false}
    }
    
    platform_unload_plugin :: proc(plugin: DynamicPlugin) {
        log.errorf("Dynamic plugin unloading not supported on this platform")
    }
    
    platform_get_function :: proc(plugin: DynamicPlugin, symbol: string) -> ^opaque {
        log.errorf("Function retrieval not supported on this platform")
        return nil
    }
}

// Helper function to convert Odin string to C string for FFI
odin_string_to_cstring :: proc(s: string) -> ^byte {
    c_str := make([]byte, len(s) + 1)
    for i, char in s {
        c_str[i] = byte(char)
    }
    c_str[len(s)] = 0  // Null-terminate
    return &c_str[0]
}