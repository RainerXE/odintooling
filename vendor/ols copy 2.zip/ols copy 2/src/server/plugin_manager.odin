package server

import "core:fmt"
import "core:log"
import "core:mem"
import "core:odin/ast"
import "core:os"
import "core:path/filepath"
import "src:common"

// Convert SimpleDiagnostic to OLS Diagnostic
convert_plugin_diagnostic :: proc(simple: SimpleDiagnostic) -> Diagnostic {
    return Diagnostic{
        range = common.Range{
            start = common.Position{line = int(simple.line), character = int(simple.column)},
            end = common.Position{line = int(simple.line), character = int(simple.column + 1)},
        },
        severity = DiagnosticSeverity(simple.severity),
        code = simple.code,
        message = simple.message,
    }
}

// The single symbol that every odin-lint .dylib must export
PluginEntryProc :: proc "c" () -> rawptr

/**
 * PluginManager is responsible for managing the lifecycle of all OLS plugins.
 * 
 * It handles plugin registration, initialization, configuration, analysis coordination,
 * and cleanup. The PluginManager ensures that plugins are properly integrated
 * into the OLS analysis pipeline.
 *
 * Key Responsibilities:
 * - Maintain registry of available plugins
 * - Coordinate plugin lifecycle events
 * - Merge plugin diagnostics with OLS diagnostics
 * - Handle plugin errors and recovery
 */
PluginManager :: struct {
    /** Array of registered plugins */
    plugins:            [dynamic]^OLSPlugin,
    /** Memory allocator for plugin management */
    allocator:         mem.Allocator,
    /** Whether the plugin system has been initialized */
    initialized:       bool,
}

/**
 * Create a new plugin manager instance.
 * 
 * Parameters:
 *   allocator: mem.Allocator - Memory allocator to use for plugin management
 * 
 * Returns: PluginManager - Initialized plugin manager ready for use
 */
create_plugin_manager :: proc(allocator: mem.Allocator) -> PluginManager {
    return PluginManager{
        plugins = make([dynamic]^OLSPlugin, 0, allocator),
        allocator = allocator,
        initialized = false,
    }
}



/**
 * Initialize all registered plugins.
 * 
 * This should be called after all plugins have been registered and OLS is ready
 * to start processing documents.
 * 
 * Parameters:
 *   manager: ^PluginManager - Plugin manager instance
 * 
 * Returns: bool - true if all plugins initialized successfully, false otherwise
 */
initialize_plugins :: proc(manager: ^PluginManager, config: ^common.Config) -> bool {
    log.infof("[PluginManager] Initializing %d plugins", len(config.plugins))
    
    manager.initialized = false
    
    // Register built-in plugins
    register_builtin_plugins(manager)
    
    // Load dynamic plugins from configuration
    load_plugins_from_config(manager, config)
    
    // Initialize all registered plugins
    for p in manager.plugins {
        if !p.initialize() {
            error_info: PluginErrorInfo;
            error_info.error_type = .InitializationFailed
            error_info.message = "Plugin initialization returned false"
            error_info.plugin = p.get_info().name
            error_info.recovery = "Check plugin logs and configuration"
            handle_plugin_error(manager, error_info)
            // Continue with other plugins even if one fails
            continue
        }
        log.infof("Initialized plugin: %s v%s", p.get_info().name, p.get_info().version)
    }
    
    manager.initialized = true
    return true
}

// Configure all plugins
configure_plugins :: proc(manager: ^PluginManager) -> bool {
    for p in manager.plugins {
        if !p.configure() {
            log.errorf("Failed to configure plugin: %s", p.get_info().name)
            return false
        }
    }
    
    return true
}

/**
 * Analyze a file with all plugins and collect diagnostics.
 * 
 * This is the core integration point where plugins participate in the
 * OLS analysis pipeline. Each plugin's analyze_file method is called,
 * and their diagnostics are collected and returned.
 * 
 * Parameters:
 *   manager: ^PluginManager - Plugin manager instance
 *   document: rawptr - Pointer to the Document being analyzed
 *   ast: ^ast.File - Abstract Syntax Tree of the document
 * 
 * Returns: [dynamic]Diagnostic - Combined diagnostics from all plugins
 */
analyze_with_plugins :: proc(manager: ^PluginManager, document: rawptr, ast: ^ast.File) -> [dynamic]Diagnostic {
    if !manager.initialized {
        log.infof("[PluginManager] analyze_with_plugins called but manager not initialized")
        return nil;
    }
    
    log.infof("[PluginManager] analyze_with_plugins called with %d plugins", len(manager.plugins))
    
    all_diagnostics: [dynamic]Diagnostic;
    
    for p in manager.plugins {
        plugin_info := p.get_info()
        log.infof("[PluginManager] Analyzing with plugin: %s", plugin_info.name)
        
        plugin_diagnostics := p.analyze_file(document, ast);
        log.infof("[PluginManager] Plugin %s returned %d diagnostics", plugin_info.name, len(plugin_diagnostics))
        
        for simple_diag in plugin_diagnostics {
            // Convert plugin diagnostic to OLS diagnostic format
            diag := convert_plugin_diagnostic(simple_diag);
            append(&all_diagnostics, diag);
        }
    }
    
    log.infof("[PluginManager] Total diagnostics from plugins: %d", len(all_diagnostics))
    return all_diagnostics;
}

// Shutdown all plugins
shutdown_plugins :: proc(manager: ^PluginManager) {
    for p in manager.plugins {
        p.shutdown()
        log.infof("Shutdown plugin: %s", p.get_info().name)
    }
    
    manager.plugins = make([dynamic]^OLSPlugin, 0, manager.allocator)
    manager.initialized = false
}

// Register a new plugin
register_plugin :: proc(manager: ^PluginManager, plugin: ^OLSPlugin) -> bool {
    // Check if plugin already exists
    for ep in manager.plugins {
        if ep.get_info().name == plugin.get_info().name {
            log.errorf("Plugin already registered: %s", plugin.get_info().name)
            return false
        }
    }
    
    append(&manager.plugins, plugin)
    log.infof("Registered plugin: %s v%s", plugin.get_info().name, plugin.get_info().version)
    return true
}

// Unregister a plugin by name
unregister_plugin :: proc(manager: ^PluginManager, plugin_name: string) -> bool {
    for i in 0..<len(manager.plugins) {
        plugin_ptr := manager.plugins[i]
        if plugin_ptr.get_info().name == plugin_name {
            plugin_ptr.shutdown()
            ordered_remove(&manager.plugins, i)
            log.infof("Unregistered plugin: %s", plugin_name)
            return true
        }
    }
    
    log.errorf("Plugin not found: %s", plugin_name)
    return false
}

// Get plugin by name
get_plugin :: proc(manager: ^PluginManager, plugin_name: string) -> (^OLSPlugin, bool) {
    for plugin in manager.plugins {
        if plugin.get_info().name == plugin_name {
            return plugin, true
        }
    }
    return nil, false
}

// Register built-in plugins
register_builtin_plugins :: proc(manager: ^PluginManager) {
    // This function can be extended to register multiple built-in plugins
    // For now, this is a placeholder for the registration mechanism
    log.infof("Plugin registration system initialized")
}

// Load plugins from configuration
load_plugins_from_config :: proc(manager: ^PluginManager, config: ^common.Config) {
    log.infof("[PluginManager] Starting plugin loading process...")
    
    if len(config.plugins) == 0 {
        log.infof("[PluginManager] No plugins configured")
        return
    }

    log.infof("[PluginManager] Loading %d plugins from configuration", len(config.plugins))

    for plugin_config in config.plugins {
        log.infof("[PluginManager] Processing plugin: %s, path: %s, enabled: %v", 
                  plugin_config.name, plugin_config.path, plugin_config.enabled)
        
        if !plugin_config.enabled {
            log.infof("[PluginManager] Skipping disabled plugin: %s", plugin_config.name)
            continue
        }

        log.infof("[PluginManager] Attempting to load plugin from: %s", plugin_config.path)

        // Load the plugin dynamically
        plugin, ok := load_plugin_library(plugin_config.path, manager.allocator)
        if !ok {
            log.errorf("[PluginManager] Failed to load plugin library: %s", plugin_config.path)
            continue
        }

        if plugin == nil {
            log.errorf("[PluginManager] Plugin loading returned nil for: %s", plugin_config.path)
            continue
        }

        log.infof("[PluginManager] Successfully loaded plugin library: %s", plugin_config.path)
        
        // Try to get plugin info to verify it loaded correctly
        plugin_info := plugin.get_info()
        log.infof("[PluginManager] Plugin info - name: %s, version: %s", plugin_info.name, plugin_info.version)
        
        if !register_plugin(manager, plugin) {
            log.errorf("[PluginManager] Failed to register plugin: %s", plugin_info.name)
            continue
        }
        
        log.infof("[PluginManager] Plugin '%s' registered successfully", plugin_info.name)
    }
    
    log.infof("[PluginManager] Plugin loading process completed - %d plugins loaded", len(manager.plugins))
}

// Load a plugin library
load_plugin_library :: proc(plugin_path: string, allocator: mem.Allocator) -> (^OLSPlugin, bool) {
    log.infof("[PluginManager] Attempting to load plugin from: %s", plugin_path)
    
    // Check if file exists first
    // Note: We'll let the platform_load_plugin handle file existence checking
    // since it will fail gracefully if the file doesn't exist
    // if !path.exists(plugin_path) {
    //     log.errorf("[PluginManager] Plugin file does not exist: %s", plugin_path)
    //     return nil, false
    // }
    
    dp := platform_load_plugin(plugin_path)
    if !dp.loaded {
        log.errorf("[PluginManager] Failed to load library: %s", plugin_path)
        return nil, false
    }

    log.infof("[PluginManager] Successfully loaded library: %s", plugin_path)
    raw := platform_get_function(dp, "get_odin_lint_plugin")
    if raw == nil {
        log.errorf("[PluginManager] Symbol 'get_odin_lint_plugin' not found in: %s", plugin_path)
        platform_unload_plugin(dp)
        return nil, false
    }

    entry := cast(PluginEntryProc)raw
    plugin_raw := entry()
    if plugin_raw == nil {
        log.errorf("[PluginManager] Entry proc returned nil from: %s", plugin_path)
        platform_unload_plugin(dp)
        return nil, false
    }

    // Cast the raw pointer to OLSPlugin
    plugin := cast(^OLSPlugin)plugin_raw
    
    // Get plugin info to verify it loaded correctly
    plugin_info := plugin.get_info()
    log.infof("[PluginManager] Loaded plugin '%s' v%s", plugin_info.name, plugin_info.version)
    
    return plugin, true
}



// Get all plugin info
get_all_plugin_info :: proc(manager: ^PluginManager) -> [dynamic]PluginInfo {
    infos: [dynamic]PluginInfo;
    
    for p in manager.plugins {
        append(&infos, p.get_info());
    }
    
    return infos;
}



// Handle plugin errors
handle_plugin_error :: proc(manager: ^PluginManager, error: PluginErrorInfo) {
    switch error.error_type {
        case .InitializationFailed:
            log.errorf("[PLUGIN ERROR] %s: Initialization failed - %s", error.plugin, error.message)
        case .AnalysisFailed:
            log.errorf("[PLUGIN ERROR] %s: Analysis failed - %s", error.plugin, error.message)
        case .ConfigurationError:
            log.errorf("[PLUGIN ERROR] %s: Configuration error - %s", error.plugin, error.message)
        case .ResourceError:
            log.errorf("[PLUGIN ERROR] %s: Resource error - %s", error.plugin, error.message)
    }
    
    if len(error.recovery) > 0 {
        log.infof("Recovery suggestion: %s", error.recovery)
    }
}