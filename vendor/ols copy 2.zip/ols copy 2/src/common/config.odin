package common

ConfigProfile :: struct {
	os:           string,
	arch:         string,
	name:         string,
	checker_path: [dynamic]string,
	defines:      map[string]string,
	exclude_path: [dynamic]string,
}

Config :: struct {
	workspace_folders:                       [dynamic]WorkspaceFolder,
	completion_support_md:                   bool,
	hover_support_md:                        bool,
	signature_offset_support:                bool,
	collections:                             map[string]string,
	running:                                 bool,
	verbose:                                 bool,
	enable_format:                           bool,
	enable_hover:                            bool,
	enable_document_symbols:                 bool,
	enable_semantic_tokens:                  bool,
	enable_unused_imports_reporting:         bool,
	enable_inlay_hints_params:               bool,
	enable_inlay_hints_default_params:       bool,
	enable_inlay_hints_implicit_return:      bool,
	enable_procedure_context:                bool,
	enable_snippets:                         bool,
	enable_references:                       bool,
	enable_document_highlights:              bool,
	enable_label_details:                    bool,
	enable_std_references:                   bool,
	enable_import_fixer:                     bool,
	enable_fake_method:                      bool,
	enable_overload_resolution:              bool,
	enable_procedure_snippet:                bool,
	enable_checker_only_saved:               bool,
	enable_checker_workspace_diagnostics:    bool,
	enable_auto_import:                      bool,
	enable_completion_matching:              bool,
	enable_document_links:                   bool,
	enable_comp_lit_signature_help:          bool,
	enable_comp_lit_signature_help_use_docs: bool,
	enable_code_action_invert_if:            bool,
	enable_private_struct_fields_underscore: bool,
	disable_parser_errors:                   bool,
	thread_count:                            int,
	file_log:                                bool,
	odin_command:                            string,
	odin_root_override:                      string,
	checker_args:                            string,
	checker_targets:                         []string,
	checker_skip_packages:                   map[string]struct{},
	client_name:                             string,
	profile:                                 ConfigProfile,
	builtin_path:                            string,
	plugins:                                 [dynamic]PluginConfig,
}

import "core:encoding/json"

// Plugin configuration
PluginConfig :: struct {
	name:       string,
	path:       string,
	enabled:   bool,
	raw_config: json.Value,  // Raw plugin configuration JSON
}

config: Config
